$(document).ready(function () {
   $("#submit").click(function () {
      // $("#formval").hide();
      // $(".introtext").hide();
      // $(".footertext").hide();
      $("body").html($("#finalsignature").html());
   });
});